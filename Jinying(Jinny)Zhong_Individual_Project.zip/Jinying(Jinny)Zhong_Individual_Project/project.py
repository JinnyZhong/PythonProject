#!/usr/bin/env python
# coding: utf-8

# In[1]:


from bs4 import BeautifulSoup
import requests
import time
import re


# In[11]:


headers = {'User-Agent': 'Mozilla/5.0'}


# # Amazon Gift Card

# In[2]:


## a) loads eBay's search result page containing sold "amazon gift card"
def saveString(htmldoc, filename="test.html"):
    try:
        file = open(filename,"w")
        file.write(str(htmldoc))
        file.close()
    except Exception as ex:
        print('Error: ' + str(ex))


# In[3]:


# save the results to file
# give the file the filename "amazon_gift_card_01.htm"
def main1a():
    url1 = "https://www.ebay.com/sch/i.html?_nkw=amazon+gift+card&LH_Sold=1"
    headers = {'User-Agent': 'Mozilla/5.0'}
    page1 = requests.get(url1, headers=headers)
    doc1 = BeautifulSoup(page1.content, 'html.parser')
    saveString(doc1,filename="/Users/zhongjinying/Desktop/Q1/amazon_gift_card_01.htm")


# In[4]:


## b)  write a loop that will download the first 10 pages of search results
# save each of these pages to "amazon_gift_card_XX.htm" (XX = page number)
# each page request needs to be followed by a 10 second pause 
def main1b():
    for i in range(1,11):
        url2 = "https://www.ebay.com/sch/i.html?_nkw=amazon+gift+card&LH_Sold=1&_pgn={}".format(str(i))
        page2 = requests.get(url2, headers=headers)
        doc2 = BeautifulSoup(page2.content, 'html.parser')
        saveString(doc2,filename="/Users/zhongjinying/Desktop/Q2_2/amazon_gift_card_{}.htm".format(str(i)))
        time.sleep(10)


# In[5]:


## c)  loops through the pages you downloaded in (b)
# opens and parses them to a Python or Java xxxxsoup-object.
def loadString(f="test.html"):
	try:
		html = open(f, "r", encoding='utf-8').read()
		return(html)
	except Exception as ex:
		print('Error: ' + str(ex))


# In[7]:


## d) identify and print to screen the title, price, and shipping price of each item.
def main1c():
    for j in range(1,11):
        # for each page
        f = '/Users/zhongjinying/Desktop/Q2/amazon_gift_card_{}.htm'.format(str(j))
        doc3 = BeautifulSoup(loadString(f),"html.parser")
        print("****************************************************************************************")
        print("In Page_{}:".format(str(j)))
        print("****************************************************************************************")
        ## d) identify and print to screen the title, price, and shipping price of each item
        itemblock = doc3.select("li.s-item.s-item__pl-on-bottom")[1:] #1:60
        for i in itemblock:
            title = i.select('div.s-item__title > span')
            price = i.select('span.s-item__price')
            ship = i.select('span.s-item__shipping.s-item__logisticsCost')
            for x in title:
                 # get rid of 'New Listing'
                if re.findall("New Listing", str(x.text)) != []:
                    x = re.sub("New Listing", "",str(x.text))
                else:
                    x = x.text
                print("Title: " + x)
            for y in price: 
                print("Price: " + y.text)
            for z in ship:
                print("Shipping Price: " + z.text)
            print("-------------------------------------")
            print("\n")


# In[12]:


# Question a to d
main1a()
main1b()
main1c()


# In[ ]:


## e) using RegEx, identify and print to screen gift cards that sold above face value


# In[14]:


# use RegEx to extract the value of a gift card from its title when possible
# doesn’t need to work on all titles, > 90% success rate if sufficient
# check if larger than 90% success rate using RegEx
pattern = "\$\d+" #regEx, real price should be with '$' sign followed by numbers
exclude_words = "MONTHS" #exclude titles with 'MONTHS' as this kind of title always contains numbers (e.g., 3/6/12), which leads to misleading results

def main1e_check():
    title_list =[]
    facevalue_title_list = []
    table_titleAndFaceValue = []
    for j in range(1,11):
        # for each page
        f = '/Users/zhongjinying/Desktop/Q2/amazon_gift_card_{}.htm'.format(str(j))
        docx = BeautifulSoup(loadString(f),"html.parser")
        title_test = docx.select('div.s-item__title > span')[1:]
        # for each title，find face value
        for itemtitle in title_test:
            t = itemtitle.text
            #print(t) 
            noprice_t = re.findall(".+[0-9]+", str(t))# check if the item title icnludes any number
            if exclude_words not in t and noprice_t !=[]:
                title_list.append(t) # official title list

            # get face value from title    
            fv = re.findall(pattern, str(t))
            #print(fv)
            if fv != []:
                facevalue_title_list.append(fv)
                new_row = [t,fv]
                table_titleAndFaceValue.append(new_row)

    # check if satisfy > 90% success rate
    success_rate = 100*round(len(facevalue_title_list)/len(title_list),4)
    print("Achieve " + str(success_rate) + "% success rate in extraction.")


# In[21]:


# compare a gift card’s value to its price + shipping
def main1eandf():
    count_totalitem = int(0)
    count_aboveface = int(0)
    for j in range(1,11):
        # for each page
        f = '/Users/zhongjinying/Desktop/Q2/amazon_gift_card_{}.htm'.format(str(j))
        doc3 = BeautifulSoup(loadString(f),"html.parser")
        ## extract face value for each item
        itemblock = doc3.select("li.s-item.s-item__pl-on-bottom")[1:] #1:60
        for i in itemblock:
            title = i.select('div.s-item__title > span')
            price = i.select('span.s-item__price')
            ship = i.select('span.s-item__shipping.s-item__logisticsCost')
            for x in title:
                has_number_price_x = re.findall(".+[0-9]+", str(x.text)) #titles must have numbers
                if exclude_words not in x.text and has_number_price_x !=[]: #titles must have numbers & can not have 'MONTHS' 
                    faceValue = re.findall(pattern, str(x.text))
                    if faceValue != []: #this item has face value extracted
                        ###print("Title: " + x.text)
                        true_num = re.findall("[0-9]+", str(faceValue))[0]
                        count_totalitem = count_totalitem + 1
                        ###print("Face Value: $" + true_num)
                        #extract corresponding selling price
                        for y in price: 
                            #print("Price: " + y.text)
                            sellingprice = re.findall("[0-9]+", str(y.text))[0]
                            ###print("Price: $" + sellingprice)
                        #extract corresponding shipping price
                        for z in ship:
                            #print("Shipping Price: " + z.text)
                            if str(z.text) == "Free shipping":
                                shippingprice = str(0)
                            else:
                                shippingprice = str(re.findall("[0-9.]+", str(z.text))) # get numbers
                                shippingprice = shippingprice.strip("[]'")
                            ###print("Shipping Price: $" + shippingprice)
                        face_totalcost_diff = float(true_num) - (float(sellingprice) + float(shippingprice))
                        face_totalcost_diff = round(face_totalcost_diff, 4)
                        ###print(face_totalcost_diff)
                        # print gift cards that sold above face value; i.e., value < price + shipping
                        if face_totalcost_diff < 0:
                            print("\n")
                            print("Gift cards that sold above face value: $" + str(abs(face_totalcost_diff)))
                            # get rid of 'New Listing'
                            if re.findall("New Listing", str(x.text)) != []:
                                x = re.sub("New Listing", "",str(x.text))
                            else:
                                x = x.text
                            print("Title: " + x)
                            print("Face Value: $" + true_num)
                            print("Price: $" + sellingprice)
                            print("Shipping Price: $" + shippingprice)
                            count_aboveface = count_aboveface+1
                        #else: 
                            #print("Gift cards that sold below face value")
                    #else:
                        #print("!! Can NOT get face value from item title !!") # title does not include dollar sign
                #else:
                    #print("!! Can NOT get face value from item title !!") # title does not include any numbers
            pass
    ## f) What fraction of Amazon gift cards sells above face value? Why do you think this is the case?
    fraction = round(count_aboveface/count_totalitem*100, 2)
    print(str(fraction) + "% of Amazon gift cards sells above face value.\n")
    print("Reasons could be:", 
              "\nSome people might want the card right now and they might not have enough time for ordering a new one and shipping. In this case, they are more willing to pay a premium. Furthermore, because of this kind of potential markets, some speculators might intentionally sell the cards at higher price.\n",
              "\nBesides, sometimes Amazon might have promotions events or discounts when customers purchase the items through gift cards. This could also encourage people to buy Amazon gift cards with a higher price.")


# In[22]:


main1e_check()
main1eandf()
#main1f()


# # Sport Betting

# In[ ]:


# a) Following the steps we discussed in class and write code that automatically logs into the website


# In[26]:


def main2():
    try:
        URL = 'https://www.fctables.com/user/login/'
        headers = {'User-Agent': 'Mozilla/5.0'}
        homepage = requests.get(URL, headers=headers)
        p = BeautifulSoup(homepage.content, 'html.parser')
        #print(p)
        time.sleep(5) 
        session_requests = requests.session()
        res = session_requests.post(URL, 
                                    data = {"login_username" : "jinny666", # username
                                            "login_password" : "jinny666", # password
                                            "user_remeber" : "1",
                                            "login_action" : "1"},
                                    headers = dict(referer = "https://www.fctables.com/user/login/"),
                                    timeout = 10)
        # use the cookies you received during log in and write code to access website
        cookies = session_requests.cookies.get_dict()
        URL_bets = "https://www.fctables.com/tipster/my_bets/"
        betspage = session_requests.get(URL_bets,cookies=cookies)
        bet = BeautifulSoup(betspage.content, 'html.parser')
        #print(bet)
        print()
        print(cookies)
    except Exception as e:
        print(f'An error occurred: {e}')
    ## b) Verify that you have successfully logged in: Check whether the word “Wolfsburg” appears on the page
    for i in bet:
        if bool(re.findall("Wolfsburg", str(i))) == True:
            print("Successfully logged in: Word “Wolfsburg” appears on the page!")
        else:
            pass


# In[27]:


main2()

